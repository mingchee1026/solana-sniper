export const markets = [];
